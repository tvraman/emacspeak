#!/bin/sh

#       Filename: /home/tcross/work/elisp/cepstral/install.sh
#  Creation Date: Sunday, 21 March 2004 06:18 PM EST
#  Last Modified: Friday, 23 April 2004 05:30 PM EST
#            Job: Cepstral speech server 
#         Author: Tim Cross <tcross@pobox.une.edu.au>
#    Description: Simple script to do the installtion of the Cepstral speech
#                 server. 
echo ""
echo ""
echo "          Emacspeak Cepstral Speech Server Installation"
echo ""
echo ""

if [ $# -ne 1 ]; then
	echo "Wrong # arguments"
	echo "Usage: $0 <path to emacspeak source tree>"
	exit -1
fi

EMACSPEAK_ROOT=$1
REPLACEMENT_FILES="Makefile lisp/Makefile lisp/dectalk-voices.el lisp/dtk-speak.el lisp/outloud-voices.el servers/.servers"
INSTALL_FILES="Makefile lisp/Makefile lisp/dectalk-voices.el lisp/dtk-speak.el lisp/outloud-voices.el lisp/ssml-voices.el servers/.servers servers/cepstral-theta/Makefile servers/cepstral-theta/tcltheta.c servers/theta"

if [ ! -d $EMACSPEAK_ROOT ]; then
	echo "Error: Cannot find $EMACSPEAK_ROOT directory"
	exit -1
fi

echo "Making backups of emacspeak files to be replaced"
echo ""

for f in $REPLACEMENT_FILES ; do
	if [ -w $EMACSPEAK_ROOT/$f ]; then
		echo "        Moving $f to $f.orig"
		mv ${EMACSPEAK_ROOT}/${f} ${EMACSPEAK_ROOT}/${f}.orig
	else
		echo "Warning: File $f either does not exist or could not be moved"
	fi
done

echo ""
echo "Making cepstral-theta directory"
if [ ! -d $EMACSPEAK_ROOT/servers/cepstral-theta ]; then
	mkdir $EMACSPEAK_ROOT/servers/cepstral-theta
fi

echo ""
echo "Installing files"

for f in $INSTALL_FILES ; do
	echo "        Installing $f"
	cp ${f} ${EMACSPEAK_ROOT}/${f}
done

echo ""
echo "Installation complete"
echo ""
echo ""
echo "Now cd to $EMACSPEAK_ROOT and do"
echo "       make clean"
echo "       make config SRC=\`pwd\`"
echo "       make emacspeak"
echo "       make install"
echo ""
echo "NOTE: After doing make install, you will need change to the directory"
echo "containing the speech server and do a make e.g. servers/cepstral-theta"
echo ""
echo "If you find things don't work, try to work out why and send me bug "
echo "reports so that I can fix things. I can be contacted at "
echo "        tcross@rapttech.com.au"
echo ""
echo "Good luck!"

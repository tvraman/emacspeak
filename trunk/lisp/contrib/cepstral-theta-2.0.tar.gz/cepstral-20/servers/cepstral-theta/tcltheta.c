/* $Id: $
/* Cepstral Theta TTS interface program for TCL
 * (c) Copyright 2003 by Tim Cross
 * All Rights Reserved
 *
 * This file is not part of GNU Emacs, but the same permissions apply.
 *
 * GNU Emacs is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * GNU Emacs is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Emacs; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* Note that this is not a completed well tested program. It is mainly a
 * proof of concept to determine the feasibility of using Cepstral's TTS
 * engine with emacspeak. It is likely this code will require significant
 * modifications before it will support many of emacspeaks more advanced
 * features, such as voice locking
 */

#include <stdio.h>
#include <tcl.h>
#include <theta.h>
#include <string.h>

#define DEBUG

#define PACKAGENAME "tts"
#define PACKAGEVERSION "1.0"

#define EXPORT
extern EXPORT int Tcltheta_Init(Tcl_Interp *interp);

void freeTTS();

#ifdef DEBUG
FILE *LOG = NULL;
int openLog(char *);
int openLog(char *logName) {

  LOG = fopen(logName, "w");
  setvbuf(LOG, NULL, _IONBF, 0);
  if (LOG == NULL) {
	return TCL_ERROR;
  }
  return TCL_OK;
}
#endif

int SetRate(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int getTTSVersion(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int Synth(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int Stop(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int SpeakingP(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int Synchronize(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int Pause(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);
int Resume(ClientData, Tcl_Interp *, int, Tcl_Obj * CONST []);

/* globals */
char error_msg[80];				/* Used to build up error messages  */
theta_async_t synth_task;		/* Speech task handle */
int task_started = 0;			/* True if there is an existing task */
int task_paused = 0;			/* True if task has been paused */


/* function called when any of the tcl commands defined in this file
 * are deleted from the TCL interpreter */
void freeTTS() {

  theta_close_async(synth_task);
  task_started = 0;
  task_paused = 0;
}

int Tcltheta_Init(Tcl_Interp *interp) {
  int status, i;
  theta_voice_desc *vlist, *vdesc;
  cst_voice *vox;

#ifdef DEBUG
  if (openLog("/tmp/tcltheta.log") == TCL_ERROR) {
	sprintf(error_msg, "Error opening log file /tmp/tcltheta.log\n");
	fprintf(stderr, error_msg);
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }
  fprintf(LOG, "Beginning Tcltheta_Init()\n");
#endif

  if (Tcl_PkgProvide(interp, PACKAGENAME, PACKAGEVERSION) != TCL_OK) {
	sprintf(error_msg, "Error loading %s\n", PACKAGENAME);
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
    return TCL_ERROR;
  }

#ifdef DEBUG
  fprintf(LOG, "Calling tts startup.\n");
#endif
  /* Call this before anything else. */
  status = theta_init(NULL);
  if (status != 0) {
	sprintf(error_msg, "Failed to initialize tts: %d\n", status);
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }

#ifdef DEBUG
  fprintf(LOG, "TTS Initialized\n");
#endif

  /* Get all the voices on the system. */ 
  if ((vlist = theta_enum_voices(NULL, NULL)) == NULL) {
	sprintf(error_msg, "%s %s", "No voices found.",
			"You may need to set THETA_VOXPATH environment variable\n");
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }

  /* Take the first one in the list. */
  vdesc = vlist;
        
  /* Load it. */
  if ((vox = theta_load_voice(vdesc)) == NULL) {
	sprintf(error_msg, "Failed to load voice %s\n", vdesc->voxname);
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }

  /* Free the list. */
  theta_free_voicelist(vlist);

  /* Set for SSML mode */
  theta_set_textmode(vox, "ssml");

#ifdef DEBUG
  fprintf(LOG, "Defining TCL commands\n");
#endif

  Tcl_CreateObjCommand(interp, "setRate", SetRate, (ClientData) vox, freeTTS);
  Tcl_CreateObjCommand(interp, "ttsVersion", getTTSVersion,
					   (ClientData) vox, NULL);
  Tcl_CreateObjCommand(interp, "synth", Synth, (ClientData) vox, freeTTS);
  Tcl_CreateObjCommand(interp, "synchronize", Synchronize,
					   (ClientData) vox, NULL);
  Tcl_CreateObjCommand(interp, "stop", Stop, (ClientData) vox, freeTTS);
  Tcl_CreateObjCommand(interp, "speakingP", SpeakingP,
					   (ClientData) vox, NULL);
  Tcl_CreateObjCommand(interp, "pause", Pause, (ClientData) vox, NULL);
  Tcl_CreateObjCommand(interp, "resume", Resume, (ClientData) vox, NULL);
  return TCL_OK;
}

int SetRate(ClientData vox, Tcl_Interp *interp,
			int objc, Tcl_Obj *CONST objv[]) {
  int rc, rate;
  double base_rate = 90;
  double new_rate;

#ifdef DEBUG
  fprintf(LOG, "Entering SetRate()\n");
#endif
  if (objc != 2) {
	sprintf(error_msg, "Usage: setRate speechRate\n");
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }
  if (Tcl_GetIntFromObj(interp, objv[1], &rate) != TCL_OK) {
	sprintf(error_msg, "Failed to get rate\n");
	Tcl_SetObjResult(interp, Tcl_NewStringObj(error_msg, -1));
	return TCL_ERROR;
  }
  /* Note that the theta TTS does not set rate by words per minute
   * but sets it as a fraction of the default rate (whatever that is)
   * so we select a base rate to represent the default rate and then
   * calculate the relative difference in the requested rate as a 
   * fraction of that rate. which is then used to set the rate */
  new_rate = base_rate / rate;
  theta_set_rate_stretch(vox, new_rate, NULL);
#ifdef DEBUG
  fprintf(LOG, "Exiting SetRate() with TCL_OK\n");
#endif
  return TCL_OK;
}

int getTTSVersion(ClientData vox, Tcl_Interp *interp,
				  int objc, Tcl_Obj *CONST objv[]) {

  Tcl_SetObjResult(interp, Tcl_NewStringObj("Theta Version 2.4", -1));
  return TCL_OK;
}

int Synth(ClientData vox, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {
  int i, length, loop_cnt;
  char *txt = NULL;

  for (i=1; i<objc; i++) {
	txt = Tcl_GetStringFromObj(objv[i], &length);
#ifdef DEBUG
	fprintf(LOG, "Synth() called with %s argument\n", txt);
#endif
	if (Tcl_StringMatch(txt, "-reset")) {
	  /* lets do nothing for now - to be done */
#ifdef DEBUG
	  fprintf(LOG, "Synth() reset - currently no-op argument\n");
#endif
	} else {
	  /* If a speech task is running, wait for it to stop before starting
	   * a new task. However, we don't want to wait forever, so lets limit
	   * it to 5 seconds */
	  if (task_started) {
/* 		if (!task_paused) { */
/* 		  loop_cnt = 0; */
/* 		  while (theta_query_async(synth_task) && */
/* 				 (loop_cnt < 5)) { */
/* #ifdef DEBUG */
/* 			fprintf(LOG, "running - sleep for 1 secs loop %d\n", loop_cnt); */
/* #endif */
/* 			sleep(1); */
/* 			loop_cnt++; */
/* 		  } */
/*		} */
		/* free resources from previous speech task - this will kill
		 * it if its still running */
		theta_close_async(synth_task);
		task_started = task_paused = 0;
	  }
	  synth_task = theta_tts_async(txt, vox);
	  task_started = 1;
	}
  }
  return TCL_OK;
}

/* Does nothing for now. Yet to determine what this will do with respect
 * to Cepstral's theta TTS */
int Synchronize(ClientData vox, Tcl_Interp *interp,
				int objc, Tcl_Obj *CONST objv[]) {
  /* do nothing for now */
  return TCL_OK;
}

int Stop(ClientData voc, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {

  if (task_started) {
	theta_close_async(synth_task);
	task_started = task_paused = 0;
  }
  return TCL_OK;
}

/* Return true if there is a currently running speech task */
int SpeakingP(ClientData vox, Tcl_Interp *interp,
			  int objc, Tcl_Obj *CONST objv[]) {
  int status = 0;

  if (task_started) {
	status = theta_query_async(synth_task);
  }
  Tcl_SetObjResult(interp, Tcl_NewIntObj(status));
  return TCL_OK;
}

/* If there is an running speech task, pause it */
int Pause(ClientData vox, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]) {

  if (task_started) {
	if (!task_paused && theta_query_async(synth_task)) {
	  theta_pause_async(synth_task);
	  task_paused = 1;
	}
  }
  return TCL_OK;
}

/* Resume speaking if previously paused and there is an existing task */
int Resume(ClientData vox, Tcl_Interp *interp, 
		   int objc, Tcl_Obj *CONST objv[]) {

  if (task_started) {
	if (task_paused && theta_query_async(synth_task)) {
	  theta_pause_async(synth_task);
	  task_paused = 0;
	}
  }
  return TCL_OK;
}



	  
	  
  
		
